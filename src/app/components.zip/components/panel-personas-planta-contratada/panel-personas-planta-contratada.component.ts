import { Component } from '@angular/core';

@Component({
  selector: 'app-panel-personas-planta-contratada',
  standalone: true,
  imports: [],
  templateUrl: './panel-personas-planta-contratada.component.html',
  styleUrl: './panel-personas-planta-contratada.component.css'
})
export class PanelPersonasPlantaContratadaComponent {

}
