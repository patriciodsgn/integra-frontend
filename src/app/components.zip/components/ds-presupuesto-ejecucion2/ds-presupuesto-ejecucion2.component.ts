import { Component } from '@angular/core';

@Component({
  selector: 'app-ds-presupuesto-ejecucion2',
  standalone: true,
  imports: [],
  templateUrl: './ds-presupuesto-ejecucion2.component.html',
  styleUrl: './ds-presupuesto-ejecucion2.component.css'
})
export class DsPresupuestoEjecucion2Component {

}
