import { Component } from '@angular/core';

@Component({
  selector: 'app-panel-dpgr-nacionalidad',
  standalone: true,
  imports: [],
  templateUrl: './panel-dpgr-nacionalidad.component.html',
  styleUrl: './panel-dpgr-nacionalidad.component.css'
})
export class PanelDpgrNacionalidadComponent {

}
