import { Component } from '@angular/core';

@Component({
  selector: 'app-elem-card-grid3',
  standalone: true,
  imports: [],
  templateUrl: './elem-card-grid3.component.html',
  styleUrl: './elem-card-grid3.component.css'
})
export class ElemCardGrid3Component {

}
