export interface CardData {
    icon: IconDefinition;
    titulo: string;
    valor: number;
    backgroundColor?: string;
}
