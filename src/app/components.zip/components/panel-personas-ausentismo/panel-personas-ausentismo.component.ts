import { Component } from '@angular/core';

@Component({
  selector: 'app-panel-personas-ausentismo',
  standalone: true,
  imports: [],
  templateUrl: './panel-personas-ausentismo.component.html',
  styleUrl: './panel-personas-ausentismo.component.css'
})
export class PanelPersonasAusentismoComponent {

}
