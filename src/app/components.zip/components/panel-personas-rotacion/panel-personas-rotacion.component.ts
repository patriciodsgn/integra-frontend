import { Component } from '@angular/core';

@Component({
  selector: 'app-panel-personas-rotacion',
  standalone: true,
  imports: [],
  templateUrl: './panel-personas-rotacion.component.html',
  styleUrl: './panel-personas-rotacion.component.css'
})
export class PanelPersonasRotacionComponent {

}
