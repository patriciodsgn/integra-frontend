import { Component } from '@angular/core';

@Component({
  selector: 'app-ds-presupuesto-daft',
  standalone: true,
  imports: [],
  templateUrl: './ds-presupuesto-daft.component.html',
  styleUrl: './ds-presupuesto-daft.component.css'
})
export class DsPresupuestoDaftComponent {

}
