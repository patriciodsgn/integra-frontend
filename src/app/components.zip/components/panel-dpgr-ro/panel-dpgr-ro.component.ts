import { Component } from '@angular/core';

@Component({
  selector: 'app-panel-dpgr-ro',
  standalone: true,
  imports: [],
  templateUrl: './panel-dpgr-ro.component.html',
  styleUrl: './panel-dpgr-ro.component.css'
})
export class PanelDpgrRoComponent {

}
