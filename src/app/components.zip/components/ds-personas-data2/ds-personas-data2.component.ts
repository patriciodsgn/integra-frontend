import { Component } from '@angular/core';

@Component({
  selector: 'app-ds-personas-data2',
  standalone: true,
  imports: [],
  templateUrl: './ds-personas-data2.component.html',
  styleUrl: './ds-personas-data2.component.css'
})
export class DsPersonasData2Component {

}
