import { Component } from '@angular/core';

@Component({
  selector: 'app-ds-educacion-atet1',
  standalone: true,
  imports: [],
  templateUrl: './ds-educacion-atet1.component.html',
  styleUrl: './ds-educacion-atet1.component.css'
})
export class DsEducacionAtet1Component {

}



