import { Component } from '@angular/core';

@Component({
  selector: 'app-ds-personas-menu',
  standalone: true,
  imports: [],
  templateUrl: './ds-personas-menu.component.html',
  styleUrl: './ds-personas-menu.component.css'
})
export class DsPersonasMenuComponent {

}
