import { Component } from '@angular/core';

@Component({
  selector: 'app-elem-draw-01',
  standalone: true,
  imports: [],
  templateUrl: './elem-draw-01.component.html',
  styleUrl: './elem-draw-01.component.css'
})
export class ElemDraw01Component {

}
