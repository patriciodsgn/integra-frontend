import { Component } from '@angular/core';

@Component({
  selector: 'app-ds-educacion-atet2',
  standalone: true,
  imports: [],
  templateUrl: './ds-educacion-atet2.component.html',
  styleUrl: './ds-educacion-atet2.component.css'
})
export class DsEducacionAtet2Component {

}
