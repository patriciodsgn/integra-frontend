import { Component } from '@angular/core';

@Component({
  selector: 'app-panel-personas-permanencia',
  standalone: true,
  imports: [],
  templateUrl: './panel-personas-permanencia.component.html',
  styleUrl: './panel-personas-permanencia.component.css'
})
export class PanelPersonasPermanenciaComponent {

}
