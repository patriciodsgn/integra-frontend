import { Component } from '@angular/core';

@Component({
  selector: 'app-panel-dppi-situacion-nutricional',
  standalone: true,
  imports: [],
  templateUrl: './panel-dppi-situacion-nutricional.component.html',
  styleUrl: './panel-dppi-situacion-nutricional.component.css'
})
export class PanelDppiSituacionNutricionalComponent {

}
