import { Component } from '@angular/core';

@Component({
  selector: 'app-panel-daft-ejecucion-presupuestaria',
  standalone: true,
  imports: [],
  templateUrl: './panel-daft-ejecucion-presupuestaria.component.html',
  styleUrl: './panel-daft-ejecucion-presupuestaria.component.css'
})
export class PanelDaftEjecucionPresupuestariaComponent {

}
