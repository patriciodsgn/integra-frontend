import { Component } from '@angular/core';

@Component({
  selector: 'app-panel-daft-saldo-por-ejecutar',
  standalone: true,
  imports: [],
  templateUrl: './panel-daft-saldo-por-ejecutar.component.html',
  styleUrl: './panel-daft-saldo-por-ejecutar.component.css'
})
export class PanelDaftSaldoPorEjecutarComponent {

}
