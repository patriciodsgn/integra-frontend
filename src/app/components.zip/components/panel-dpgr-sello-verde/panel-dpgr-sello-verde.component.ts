import { Component } from '@angular/core';

@Component({
  selector: 'app-panel-dpgr-sello-verde',
  standalone: true,
  imports: [],
  templateUrl: './panel-dpgr-sello-verde.component.html',
  styleUrl: './panel-dpgr-sello-verde.component.css'
})
export class PanelDpgrSelloVerdeComponent {

}
