import { Component } from '@angular/core';

@Component({
  selector: 'app-elem-title',
  standalone: true,
  imports: [],
  templateUrl: './elem-title.component.html',
  styleUrl: './elem-title.component.css'
})
export class ElemTitleComponent {

}
