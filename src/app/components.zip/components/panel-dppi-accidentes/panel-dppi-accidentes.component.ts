import { Component } from '@angular/core';

@Component({
  selector: 'app-panel-dppi-accidentes',
  standalone: true,
  imports: [],
  templateUrl: './panel-dppi-accidentes.component.html',
  styleUrl: './panel-dppi-accidentes.component.css'
})
export class PanelDppiAccidentesComponent {

}
