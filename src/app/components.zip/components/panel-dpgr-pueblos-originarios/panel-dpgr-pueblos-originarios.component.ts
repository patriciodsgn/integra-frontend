import { Component } from '@angular/core';

@Component({
  selector: 'app-panel-dpgr-pueblos-originarios',
  standalone: true,
  imports: [],
  templateUrl: './panel-dpgr-pueblos-originarios.component.html',
  styleUrl: './panel-dpgr-pueblos-originarios.component.css'
})
export class PanelDpgrPueblosOriginariosComponent {

}
