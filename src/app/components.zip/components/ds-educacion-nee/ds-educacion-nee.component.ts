import { Component } from '@angular/core';

@Component({
  selector: 'app-ds-educacion-nee',
  standalone: true,
  imports: [],
  templateUrl: './ds-educacion-nee.component.html',
  styleUrl: './ds-educacion-nee.component.css'
})
export class DsEducacionNeeComponent {

}
