import { Component } from '@angular/core';

@Component({
  selector: 'app-elem-card-grid2',
  standalone: true,
  imports: [],
  templateUrl: './elem-card-grid2.component.html',
  styleUrl: './elem-card-grid2.component.css'
})
export class ElemCardGrid2Component {

}
